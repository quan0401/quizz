import { useState } from 'react'
import QuizTable from './QuizTable'
import Quiz from './QuizTable'


function App() {

  return (
    <div style={{
      marginTop: 40,
    }}>
      <Quiz/>
    </div>
  )
}

export default App
